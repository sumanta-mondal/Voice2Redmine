// VorbisEnc.h


#pragma once

using namespace System;

namespace VorbisEnc {

	private struct IVorbisEnc
	{
		//IVorbisEnc(void);
		ogg_stream_state os; /* take physical pages, weld into a logical
							 stream of packets */
		ogg_page         og; /* one Ogg bitstream page.  Vorbis packets are inside */
		ogg_packet       op; /* one raw packet of data for decode */

		vorbis_info      vi; /* struct that stores all the static vorbis bitstream
							 settings */
		vorbis_comment   vc; /* struct that stores all the user comments */

		vorbis_dsp_state vd; /* central working state for the packet->PCM decoder */
		vorbis_block     vb; /* local working space for packet->PCM decode */
		FILE* _oggfile;
		int channels;
	public:
		~IVorbisEnc(void);
		int Initialise(char* stringFile, int channels, int rate, double q, Tag^ t);
		void Close(void);
		void UploadChunk(signed char* data, long sz);
		void UploadChunk32(signed char* data, long sz);
	};
	public ref class VorbisEnc
	{

	public:
		void VorbisEnc_lib_Vitaliy_Burdenkov_aka_Cerriun(){}
		void PleaseVisit_http___www_xiph_org_(){}
		VorbisEnc()
		{
			VorbisEncInner = 0;
		}
		void* VorbisEncInner;
		void Initialise(char* stringFile)
		{
			if(VorbisEncInner != 0)
				Close();
			VorbisEncInner = malloc(sizeof(IVorbisEnc));
			memset(VorbisEncInner, 0, sizeof(IVorbisEnc));
			//***
			IVorbisEnc* encoder = (IVorbisEnc*)VorbisEncInner;
			encoder->Initialise(stringFile, 2, 44100, 0.1, gcnew Tag());
		}
		void Initialise(char* stringFile, int channels, int rate, double q, Tag^ t)
		{
			if(VorbisEncInner != 0)
				Close();
			VorbisEncInner = malloc(sizeof(IVorbisEnc));
			memset(VorbisEncInner, 0, sizeof(IVorbisEnc));
			//***
			IVorbisEnc* encoder = (IVorbisEnc*)VorbisEncInner;
			encoder->Initialise(stringFile, channels, rate, q, t);
		}
		void Encode(char* data, long sizeBT4096)
		{	
			if(VorbisEncInner == 0)
				return;
			IVorbisEnc* encoder = (IVorbisEnc*)VorbisEncInner;
			encoder->UploadChunk((signed char*)data,sizeBT4096);
		}
		void Encode32(char* data, long sizeBT4096)
		{	
			if(VorbisEncInner == 0)
				return;
			IVorbisEnc* encoder = (IVorbisEnc*)VorbisEncInner;
			encoder->UploadChunk32((signed char*)data,sizeBT4096);
		}
		void Close()
		{			
			if(VorbisEncInner == 0)
				return;
			IVorbisEnc* encoder = (IVorbisEnc*)VorbisEncInner;
			encoder->Close();
			free(VorbisEncInner);
			VorbisEncInner = 0;
		}
		~VorbisEnc()
		{
			Close();
		}
	};
	public ref class CircleBuffer
	{
	public:
		void VorbisEnc_lib_Vitaliy_Burdenkov_aka_Cerriun(){}
		CircleBuffer()
		{
			unsigned int buffsz=4096*25;
			stock_buffer* abuf=stock_buf::sbcreate(4096*10);
			Abuffer = abuf;
		}
		~CircleBuffer()
		{
			stock_buffer* abuf = (stock_buffer*)Abuffer;
			stock_buf::sbclose(abuf);
			abuf = 0;
		}

		void* Abuffer;

		int getNeedForUpdate()
		{
			stock_buffer* abuf = (stock_buffer*)Abuffer; 
			return abuf->needupdate;
		}
		void Upload(void* buffer, long size)
		{
			//unsigned int insz = (unsigned int)size;
			stock_buffer* abuf = (stock_buffer*)Abuffer;
			abuf->push((char*)buffer, size);
		}
		int Download(void* buffer, long size)
		{
			unsigned int insz = (unsigned int)size;
			stock_buffer* abuf = (stock_buffer*)Abuffer;
			abuf->pop((char*)buffer,&insz);
			return insz;
		}
		void Echo(void* buffer, int size){}//echo statistiqs
	};

	
}
