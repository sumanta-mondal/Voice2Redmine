#include "stdafx.h"
#include "stock_buffer.h"

stock_buffer* stock_buf::sbcreate(int size)
{
    stock_buffer* sobj= (stock_buffer*) malloc(sizeof(stock_buffer));
	memset(sobj,0,sizeof(stock_buffer));
    sobj->ptr=(char*)malloc(size);
    sobj->size=size;
    sobj->needupdate=size;
    sobj->updateCritical=size/4;
    sobj->origin=-1;
    return sobj;
}
void stock_buf::sbclose(stock_buffer* sb)
{
    free(sb->ptr);
    free(sb);
}