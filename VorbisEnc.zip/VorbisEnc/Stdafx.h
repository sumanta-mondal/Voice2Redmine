// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

//vorbis
#include <vorbis/vorbisenc.h>

//mpeg
#include "mad.h"

//flac
#include "FLAC/metadata.h"
#include "FLAC/stream_encoder.h"

#define FIXED32_FRACBITS 28
#define FIXED32_MIN ((int) -0x80000000L)
#define FIXED32_MAX ((int) +0x7fffffffL)
#define FIXED32_ONE ((int) 0x10000000)


#ifdef _WIN32 /* We need the following two to set stdin/stdout to binary */
#include <io.h>
#include <fcntl.h>
#endif

#if defined(__MACOS__) && defined(__MWERKS__)
#include <console.h>      /* CodeWarrior's Mac "command-line" support */
#endif