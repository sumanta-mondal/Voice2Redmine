#ifndef fretstockbuff
#define fretstockbuff
typedef struct
{
    char* ptr;
    unsigned int size;
    int cursor;
    unsigned int needupdate;
    bool oldbuffer;
    unsigned int updateCritical;
    int origin;

    void push(char* buf,int sz);
    void pop(char* buf,unsigned int* sz);

}stock_buffer;

namespace stock_buf
{
    stock_buffer* sbcreate(int size);
    void sbclose(stock_buffer* sb);
};
#endif