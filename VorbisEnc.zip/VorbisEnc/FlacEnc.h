
#pragma once

using namespace System;

namespace VorbisEnc {

	private struct IFlacEnc
	{
		FILE* flacfile;
		FLAC__StreamEncoder* encoder;
		FLAC__StreamMetadata *metadata1;
		FLAC__StreamMetadata *metadata2;
	public:
		bool Start(char* strpath);
		void Close(void);
		void UploadChunk(signed char* data, long sz);
		~IFlacEnc(void);
	};
	public ref class FlacEncoder
	{
	public:
		void VorbisEnc_lib_Vitaliy_Burdenkov_aka_Cerriun(){}
		void PleaseVisit_http___flac_sourceforge_net_(){}
		void* FlacEncInner;
		FlacEncoder()
		{
			FlacEncInner = 0;
		}
		~FlacEncoder()
		{

		}
		void Initialise(char* stringFile)
		{
			if(FlacEncInner != 0)
				Close();
			FlacEncInner = malloc(sizeof(IFlacEnc));
			memset(FlacEncInner, 0, sizeof(IFlacEnc));
			//***
			IFlacEnc* encoder = (IFlacEnc*)FlacEncInner;
			encoder->flacfile = 0;
			encoder->Start(stringFile);
		}
		void Encode(char* data, long sizeBT4096)
		{	
			if(FlacEncInner == 0)
				return;
			IFlacEnc* encoder = (IFlacEnc*)FlacEncInner;
			encoder->UploadChunk((signed char*)data,sizeBT4096);
		}
		void Close()
		{			
			if(FlacEncInner == 0)
				return;
			IFlacEnc* encoder = (IFlacEnc*)FlacEncInner;
			encoder->Close();
			free(FlacEncInner);
			FlacEncInner = 0;
		}
	};
}