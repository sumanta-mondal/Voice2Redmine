#include "StdAfx.h"

#include "MpegDec.h"
#include "Tags.h"

//# include "id3tag.h"
//# include "file.h"
//# include "tag.h"
//# include "field.h"

#define ID3v2_FLAG_UNSYNC   0x80
#define ID3v2_FLAG_EXTENDEDHEADER 0x40
#define ID3v2_FLAG_EXPERIMENTAL  0x20
#define ID3v2_FLAG_FOOTER   0x10

typedef struct _CIs_ID3Tag
{
	char m_cTAG[3];  // Must equal "TAG"
	char m_cSong[30];
	char m_cArtist[30];
	char m_cAlbum[30];
	char m_cYear[4];
	char m_cComment[30];
	unsigned char m_cGenre;
} CIs_ID3Tag;

typedef struct _CIs_ID3v2Frame
{
	char m_cFrameID[4];
	unsigned char m_cSize_Encoded[4];
	unsigned short m_cFlags;
} CIs_ID3v2Frame;


static void CPLI_ReadTag_ID3v2(FILE* filemp3, VorbisEnc::Tag^ t)
{
	long dwBytesRead;
	int iTagDataToRead;
	CIs_ID3v2Tag ID3v2;
	
	//SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
	//ReadFile(hFile, &ID3v2, sizeof(ID3v2), &dwBytesRead, NULL);
	//fsetpos(filemp3, 0);
	fseek(filemp3, 0, SEEK_SET);
	dwBytesRead = fread(&ID3v2, 1, sizeof(ID3v2), filemp3);
	
	// Not enough file data returned - or the data returned does not look like an ID3
	
	if (dwBytesRead != sizeof(ID3v2)
			|| memcmp(ID3v2.m_cTAG, "ID3", 3) != 0
			|| (ID3v2.m_cVersion[0] != 0x03 && ID3v2.m_cVersion[0] != 0x04)) // Major version wrong
	{
		return;
	}
	
	// Work out the amount of tag left to read
	iTagDataToRead = (ID3v2.m_cSize_Encoded[0] << 21)
					 | (ID3v2.m_cSize_Encoded[1] << 14)
					 | (ID3v2.m_cSize_Encoded[2] << 7)
					 | ID3v2.m_cSize_Encoded[3];
	                 
	// Check for a big enough file now (to save endless checking)
	//if (GetFileSize(hFile, NULL) < (sizeof(ID3v2) + iTagDataToRead))
	long pmp3p = ftell(filemp3);
	fseek(filemp3, 0, SEEK_END);
	if (ftell(filemp3) < (sizeof(ID3v2) + iTagDataToRead))
		return;
	
	fseek(filemp3, pmp3p, SEEK_SET);
	// Skip over extended header (if there is one)
	if (ID3v2.m_cFlags & ID3v2_FLAG_EXTENDEDHEADER)
	{
		char cExtendedHeaderSize_Encoded[4];
		int iExtendedHeaderSize;
		
		//ReadFile(hFile, cExtendedHeaderSize_Encoded, sizeof(cExtendedHeaderSize_Encoded), &dwBytesRead, NULL);
		dwBytesRead = fread(cExtendedHeaderSize_Encoded, 1, sizeof(cExtendedHeaderSize_Encoded), filemp3);
		
		iExtendedHeaderSize = (cExtendedHeaderSize_Encoded[0] << 21)
							  | (cExtendedHeaderSize_Encoded[1] << 14)
							  | (cExtendedHeaderSize_Encoded[2] << 7)
							  | cExtendedHeaderSize_Encoded[3];
		                      
		//SetFilePointer(hFile, iExtendedHeaderSize - sizeof(cExtendedHeaderSize_Encoded), NULL, FILE_CURRENT);
		fseek(filemp3, iExtendedHeaderSize - sizeof(cExtendedHeaderSize_Encoded), SEEK_CUR);
		iTagDataToRead -= iExtendedHeaderSize;
	}
	
	while (iTagDataToRead > sizeof(CIs_ID3v2Frame))
	{
		CIs_ID3v2Frame ID3v2Frame;
		char* pFrameData;
		int iFrameSize;
		
		//ReadFile(hFile, &ID3v2Frame, sizeof(ID3v2Frame), &dwBytesRead, NULL);
		dwBytesRead = fread(&ID3v2Frame, 1, sizeof(ID3v2Frame), filemp3);

		// Have we encountered padding?
		
		if (ID3v2Frame.m_cFrameID[0] == '\0')
			break;
			
		if (ID3v2.m_cVersion[0] == 0x03)
		{
			iFrameSize = (ID3v2Frame.m_cSize_Encoded[0] << 24)
						 | (ID3v2Frame.m_cSize_Encoded[1] << 16)
						 | (ID3v2Frame.m_cSize_Encoded[2] << 8)
						 | ID3v2Frame.m_cSize_Encoded[3];
		}
		
		else
		{
			iFrameSize = (ID3v2Frame.m_cSize_Encoded[0] << 21)
						 | (ID3v2Frame.m_cSize_Encoded[1] << 14)
						 | (ID3v2Frame.m_cSize_Encoded[2] << 7)
						 | ID3v2Frame.m_cSize_Encoded[3];
		}
		
		// Frame size invalid?
		
		if (iFrameSize > iTagDataToRead)
			return;
			
		pFrameData = (char*)malloc(iFrameSize + 1);
		
		//if (!ReadFile(hFile, pFrameData, iFrameSize, &dwBytesRead, NULL)) return;
		dwBytesRead = fread(pFrameData, 1, iFrameSize, filemp3);
		if (!dwBytesRead) return;

		pFrameData[iFrameSize] = '\0';
		
		// Decode frames
		t->Set(ID3v2Frame.m_cFrameID, pFrameData, iFrameSize);
		
		/*else if (memcmp(ID3v2Frame.m_cFrameID, "TLEN", 4) == 0)
		{
			char* pcLength = CPLI_ID3v2_DecodeString(pFrameData, iFrameSize);
			
			if (pcLength)
			{
				CPLI_DecodeLength(pItem, atoi(pcLength) / 1000);
				free(pcLength);
			}
		}*/
		
#ifdef _DEBUG
		/*if(ID3v2Frame.m_cFrameID[0] == 'T')
		{
			printf("Text frame %4s \"%s\"\n", ID3v2Frame.m_cFrameID, pFrameData+1);
			
		}else
		{
			printf("Any old frame %4s\n", ID3v2Frame.m_cFrameID);
		}*/
		/*
		else if(ID3v2Frame.m_cFrameID[0] == 'T')
		 CP_TRACE2("Text frame %4s \"%s\"", ID3v2Frame.m_cFrameID, pFrameData+1);
		else
		 CP_TRACE1("Any old frame %4s", ID3v2Frame.m_cFrameID);
		*/
#endif
		free(pFrameData);
		
		iTagDataToRead -= iFrameSize + sizeof(ID3v2Frame);
	}
	
//	pItem->m_enTagType = ttID3v2;
}
static void CPLI_ReadTag_ID3v1(FILE* filemp3, VorbisEnc::Tag^ t)
{
	long dwBytesRead;
	CIs_ID3Tag ID3;
	
	fseek(filemp3, 0 - sizeof(ID3), SEEK_END);
	dwBytesRead = fread(&ID3, 1, sizeof(ID3), filemp3);
	// Not enough file data returned - or the data returned does not look like an ID3
	
	if (dwBytesRead != sizeof(ID3) || memcmp(ID3.m_cTAG, "TAG", 3) != 0)
		return;
		
	// Decode the fixed strings into our dynamic strings
	if(ID3.m_cSong[0])t->Set("TIT2", ID3.m_cSong, 30);
	if(ID3.m_cArtist[0])t->Set("TPE1", ID3.m_cArtist, 30);
	if(ID3.m_cAlbum[0])t->Set("TALB", ID3.m_cAlbum, 30);
	if(ID3.m_cYear[0])t->Set("TYER", ID3.m_cYear, 4);
	// ID3v1.1 - If the 29th byte of the comment is 0 then the 30th byte is the track num
	// ** Some dodgy implementations of ID3v1.1 just slap a <32 char byte at position 30 and hope
	//    for the best - handle these too <hmph!>
	if (ID3.m_cComment[28] == '\0' || ID3.m_cComment[29] < 32)
	{
		char cTempString[33];
		
		if(ID3.m_cComment[0])t->Set("COMM", ID3.m_cComment, 28);
		/*pItem->m_pcComment = DecodeID3String(ID3.m_cComment, 28);
		pItem->m_cTrackNum = ID3.m_cComment[29];
		
		if (pItem->m_cTrackNum != CIC_INVALIDTRACKNUM)
		{
			_itoa(pItem->m_cTrackNum, cTempString, 10);
			pItem->m_pcTrackNum_AsText = (char*)malloc(CPC_TRACKNUMASTEXTBUFFERSIZE);
			strncpy(pItem->m_pcTrackNum_AsText, cTempString, CPC_TRACKNUMASTEXTBUFFERSIZE);
		}*/
	}
	
	else
	{
		if(ID3.m_cComment[0])t->Set("COMM", ID3.m_cComment, 30);
		//pItem->m_cTrackNum = CIC_INVALIDTRACKNUM;
	}
	if (ID3.m_cGenre < 149)
	{
		char cTempString[33];
		itoa((int)ID3.m_cGenre, cTempString, 10);
		t->Set("TCON", cTempString, strlen(cTempString) + 1);
	}
}
VorbisEnc::Tags::Tags(void)
{

}

//static void CPLI_ReadTag_ID3Alt(FILE* filemp3, VorbisEnc::Tag^ t)
//{
//	void* tagf = id3_file_openio(filemp3, id3_file_mode::ID3_FILE_MODE_READONLY);
//	if(tagf == 0)return; 
//	
//	id3_tag *tag = id3_file_tag(tagf);
//	if(tag == 0){id3_file_close(tagf); return;}
//
//	for(int i = 0; i < tag->nframes; i++)
//	{
//		id3_frame* fnow = tag->frames[i];
//		for(int j = 0; j < fnow->nfields; j++)
//		{
//			id3_field fld = fnow->fields[j];
//			/*void* flds = fnow->fields;
//			id3_field* fld = ((id3_field**)flds)[j];*/
//			//t->Set(fnow->id, fld->);
//			//break;
//		}
//	}
//
//	id3_file_close(tagf);
//}
void VorbisEnc::Tags::TryReadTagMp3(FILE* mp3, Tag^ t)
{
	//CPLI_ReadTag_ID3Alt(mp3, t);
	//CPLI_ReadTag_ID3v1(mp3, t);
	//CPLI_ReadTag_ID3v2(mp3, t);
	fseek(mp3, 0, SEEK_SET);
}