// MpegDec.h


#pragma once

typedef struct _CIs_ID3v2Tag
{
	char m_cTAG[3];  // Must equal ID3
	unsigned char m_cVersion[2]; // Major / Minor
	unsigned char m_cFlags;
	unsigned char m_cSize_Encoded[4];
} CIs_ID3v2Tag;

struct xing
{
	long flags;
	unsigned long frames;
	unsigned long bytes;
	unsigned char toc[100];
	long scale;
};
enum
{
	XING_FRAMES = 0x00000001L,
	XING_BYTES  = 0x00000002L,
	XING_TOC    = 0x00000004L,
	XING_SCALE  = 0x00000008L
};

# define XING_MAGIC (('X' << 24) | ('i' << 16) | ('n' << 8) | 'g')

struct dither
{
	signed int error[3];
	signed int random;
};
struct mpegMythos
{
    struct xing xing;    /* Xing VBR tag data */
    struct mad_stream stream;  /* MAD stream structure */
	struct mad_frame frame;   /* MAD frame structure */
	struct mad_synth synth;   /* MAD synth structure */
    bool stereo;	
    unsigned long rate;    /* bitrate sum for computing average */
	unsigned long frames;   /* number of frames decoded */	
    unsigned char buffer[40000]; /* input stream buffer */
	unsigned int buflen;   /* input stream buffer length */
    unsigned int samplecount;  /* samples output from current frame */
    mad_timer_t timer;    /* current playing time position */
	mad_timer_t length;    /* total playing time of current stream */
};

using namespace System;

namespace VorbisEnc {

	private struct IMpegDec
	{
		//IMpegDec(void);
		mpegMythos* mythos;
		void HWinfo(int* channels, int* samplerate, long* bitrate);
	public:
		long _mpegfilelength;
		FILE* _mpegfile;
	public:
		~IMpegDec(void);
		int Initialise(char* stringFile);
		void Close(void);
		int ReadChunk(signed char* data, long sz);
		int ReadChunk32(signed char* data, long sz);
	};

	public ref class MpegDec
	{

	public:
		/*void VorbisEnc_lib_Vitaliy_Burdenkov_aka_Cerriun(){}
		void PleaseVisit_http___www_xiph_org_(){}*/
		MpegDec()
		{
			MpegDecInner = 0;
		}
		void* MpegDecInner;
		void Initialise(char* stringFile)
		{
			if(MpegDecInner != 0)
				Close();
			MpegDecInner = malloc(sizeof(IMpegDec));
			memset(MpegDecInner, 0, sizeof(IMpegDec));
			//***
			IMpegDec* decoder = (IMpegDec*)MpegDecInner;
			decoder->Initialise(stringFile);
		}
		
		int Decode(char* data, long sizeBT4096)
		{	
			if(MpegDecInner == 0)
				return -1;
			IMpegDec* decoder = (IMpegDec*)MpegDecInner;
			return decoder->ReadChunk((signed char*)data,sizeBT4096);
		}
		int Decode32(char* data, long sizeBT4096)
		{	
			if(MpegDecInner == 0)
				return -1;
			IMpegDec* decoder = (IMpegDec*)MpegDecInner;
			return decoder->ReadChunk32((signed char*)data,sizeBT4096);
		}
		double ThousandPosition()
		{
			if(MpegDecInner == 0)
				return -1;
			IMpegDec* decoder = (IMpegDec*)MpegDecInner;
			double rd = (double)decoder->_mpegfilelength;
			double npos = (double)ftell(decoder->_mpegfile);

			return (1000.0 / rd) * npos;
		}
		void Close()
		{			
			if(MpegDecInner == 0)
				return;
			IMpegDec* decoder = (IMpegDec*)MpegDecInner;
			decoder->Close();
			free(MpegDecInner);
			MpegDecInner = 0;
		}
		void Info(int* channels, int* rate, long* bitrate)
		{
			if(MpegDecInner == 0)
				return;
			IMpegDec* decoder = (IMpegDec*)MpegDecInner;
			decoder->HWinfo(channels, rate, bitrate);
		}
		~MpegDec()
		{
			Close();
		}
	};
}
