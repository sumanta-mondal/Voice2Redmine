
#include "stdafx.h"
//#include "stock_buffer.h"

#include "MpegDec.h"

#define READ 1024

static
int parse_xing(struct xing *xing, struct mad_bitptr ptr, unsigned int bitlen)
{
    if (bitlen < 64 || mad_bit_read(&ptr, 32) != XING_MAGIC)
        goto fail;

    xing->flags = mad_bit_read(&ptr, 32);

    bitlen -= 64;

    if (xing->flags & XING_FRAMES)
    {
        if (bitlen < 32)
            goto fail;

        xing->frames = mad_bit_read(&ptr, 32);

        bitlen -= 32;
    }

    if (xing->flags & XING_BYTES)
    {
        if (bitlen < 32)
            goto fail;

        xing->bytes = mad_bit_read(&ptr, 32);

        bitlen -= 32;
    }

    if (xing->flags & XING_TOC)
    {
        int i;

        if (bitlen < 800)
            goto fail;

        for (i = 0; i < 100; ++i)
            xing->toc[i] = (unsigned char) mad_bit_read(&ptr, 8);

        bitlen -= 800;
    }

    if (xing->flags & XING_SCALE)
    {
        if (bitlen < 32)
            goto fail;

        xing->scale = mad_bit_read(&ptr, 32);

        bitlen -= 32;
    }

    return 0;

fail:
    xing->flags = 0;
    return -1;
}
static
int scan_header(FILE* pInStream, struct mad_header *header, struct xing *xing)
{

    struct mad_stream stream;

    struct mad_frame frame;
    unsigned char buffer[8192];
    unsigned int buflen = 0;
    int count = 0, result = 0;

    mad_stream_init(&stream);
    mad_frame_init(&frame);

    if (xing)
        xing->flags = 0;

    while (1)
    {
        if (buflen < sizeof(buffer))
        {
            // DWORD bytes;
            unsigned int bytes;

            bytes=fread(buffer + buflen,1,sizeof(buffer) - buflen,pInStream);
            if(bytes<=0)
            {
                result = -1;
                break;
            }

            buflen += bytes;
        }

        mad_stream_buffer(&stream, buffer, buflen);

        while (1)
        {
            if (mad_frame_decode(&frame, &stream) == -1)
            {
                if (!MAD_RECOVERABLE(stream.error))
                    break;

                continue;
            }

            if (count++ ||
                (xing && parse_xing(xing, stream.anc_ptr,
                stream.anc_bitlen) == 0))
                break;
        }

        if (count || stream.error != MAD_ERROR_BUFLEN)
            break;

        memmove(buffer, stream.next_frame,
            buflen = &buffer[buflen] - stream.next_frame);
    }

    if (count)
    {
        if (header)
            *header = frame.header;
    }

    else
        result = -1;

    mad_frame_finish(&frame);

    mad_stream_finish(&stream);

    return result;
}
static __inline
unsigned long prng(unsigned long state)
{
    return (state * 0x0019660dL + 0x3c6ef35fL) & 0xffffffffL;
}

static __inline
signed int dither32(mad_fixed_t sample, struct dither *dither)
{
	return sample;
}
static __inline
signed int dither(mad_fixed_t sample, struct dither *dither)
{
    unsigned int scalebits;
    mad_fixed_t output, mask, random;

    enum
    {
        MIN = -MAD_F_ONE,
        MAX =  MAD_F_ONE - 1
    };

    /* noise shape */
    sample += dither->error[0] - dither->error[1] + dither->error[2];

    dither->error[2] = dither->error[1];
    dither->error[1] = dither->error[0] / 2;

    /* bias */
    output = sample + (1L << (MAD_F_FRACBITS + 1 - 16 - 1));//16->simple depth

    scalebits = MAD_F_FRACBITS + 1 - 16;//16->simple depth
    mask = (1L << scalebits) - 1;

    /* dither */
    random  = prng(dither->random);
    output += (random & mask) - (dither->random & mask);

    dither->random = random;

    /* clip */

    if (output > MAX)
    {
        output = MAX;

        if (sample > MAX)
            sample = MAX;
    }

    else if (output < MIN)
    {
        output = MIN;

        if (sample < MIN)
            sample = MIN;
    }

    /* quantize */
    output &= ~mask;

    /* error feedback */
    dither->error[0] = sample - output;

    /* scale */
    return output >> scalebits;
}
#define SAMPLE_DEPTH 16
# define scale(x, y) dither((x), (y))
static
void pack_pcm(unsigned char **pcm, unsigned int nsamples,
              mad_fixed_t const *ch1, mad_fixed_t const *ch2)
{
    register signed int s0, s1;

    static struct dither d0, d1;

    if (ch2)    /* stereo */
    {
        while (nsamples--)
        {
            s0 = scale(*ch1++, &d0);
            s1 = scale(*ch2++, &d1);
# if SAMPLE_DEPTH == 16
            (*pcm)[0 + 0] = s0 >> 0;
            (*pcm)[0 + 1] = s0 >> 8;
            (*pcm)[2 + 0] = s1 >> 0;
            (*pcm)[2 + 1] = s1 >> 8;

            *pcm += 2 * 2;
# elif SAMPLE_DEPTH == 8
            (*pcm)[0] = s0 ^ 0x80;
            (*pcm)[1] = s1 ^ 0x80;

            *pcm += 2;
# else
#  error "bad SAMPLE_DEPTH"
# endif
        }
    }

    else    /* mono */
    {
        while (nsamples--)
        {
            s0 = scale(*ch1++, &d0);

# if SAMPLE_DEPTH == 16
            (*pcm)[0] = s0 >> 0;
            (*pcm)[1] = s0 >> 8;

            *pcm += 2;
# elif SAMPLE_DEPTH == 8
            *(*pcm)++ = s0 ^ 0x80;
# endif
        }
    }
}
void pack_pcmf32(unsigned char **pcm, unsigned int nsamples,
              mad_fixed_t const *ch1, mad_fixed_t const *ch2)
{
    register signed int s0, s1;

    //static struct dither d0, d1;

    if (ch2)    /* stereo */
    {
        while (nsamples--)
        {
            s0 = *ch1++;
            s1 = *ch2++;

            //s0 = dither32(*ch1++, &d0);
            //s1 = dither32(*ch2++, &d1);

            (*pcm)[0 + 0] = (s0 >> 0)& 0xff;
            (*pcm)[0 + 1] = (s0 >> 8)& 0xff;
			(*pcm)[0 + 2] = (s0 >> 16)& 0xff;
			(*pcm)[0 + 3] = (s0 >> 24)& 0xff;

            (*pcm)[4 + 0] = (s1 >> 0)& 0xff;
            (*pcm)[4 + 1] = (s1 >> 8)& 0xff;
			(*pcm)[4 + 2] = (s1 >> 16)& 0xff;
			(*pcm)[4 + 3] = (s1 >> 24)& 0xff;
            *pcm += 2 * 4;
        }
    }

    else    /* mono */
    {
        while (nsamples--)
        {
            s0 = *ch1++;

            (*pcm)[0] = s0 >> 0;
            (*pcm)[1] = s0 >> 8;
			(*pcm)[2] = s0 >> 16;
			(*pcm)[3] = s0 >> 24;

            *pcm += 4;

        }
    }
}
//====================================================================================================
//====================================================================================================
//====================================================================================================
//============================================================ DOWN HERE ====================
static int readMPEGChunkF32(FILE* f, mpegMythos* mythos, signed char* bufA)
{
    int readed=0;
    unsigned int nsamples = (READ / (32 / 8)) >>
        (mythos->stereo ? 1 : 0);

    unsigned char *samples = (unsigned char*)bufA;
    while (nsamples)
    {
        unsigned int count, bitrate;

        count = mythos->synth.pcm.length - mythos->samplecount;

        if (count > nsamples)
		{
			//count = nsamples;
			nsamples=count;
		}

        if (count)
        {
            mad_fixed_t const *ch1, *ch2;

            ch1 = mythos->synth.pcm.samples[0] + mythos->samplecount;
            ch2 = mythos->synth.pcm.samples[1] + mythos->samplecount;

            if (mythos->stereo == false)
                ch2 = 0;
            else if (mythos->synth.pcm.channels == 1)
                ch2 = ch1;

            pack_pcmf32(&samples, count, ch1, ch2);

            mythos->samplecount += count;

            nsamples             -= count;

            if (nsamples == 0)
                break;
        }

        while (mad_frame_decode(&mythos->frame, &mythos->stream) == -1)
        {
            // DWORD bytes;
            unsigned int bytes;

            if (MAD_RECOVERABLE(mythos->stream.error))
			continue;

            if (mythos->stream.next_frame)
            {
                memmove(mythos->buffer, mythos->stream.next_frame,
                    mythos->buflen = mythos->buffer +
                    mythos->buflen - mythos->stream.next_frame);
            }

            //bytes=fread(mythos->buffer + mythos->buflen,1,sizeof(mythos->buffer) - mythos->buflen,f);
			bytes = fread(mythos->buffer + mythos->buflen, 1, sizeof(mythos->buffer) - mythos->buflen, f);
            if(bytes<=0)
            {
                return NULL;
            }

            mad_stream_buffer(&mythos->stream,

                mythos->buffer, mythos->buflen += bytes);
        }

        bitrate = mythos->frame.header.bitrate / 1000;

        mythos->rate += bitrate;
        mythos->frames++;

        //        mythos->info.m_iBitRate_Kbs = bitrate;

        mad_synth_frame(&mythos->synth, &mythos->frame);

        mythos->samplecount = 0;

        mad_timer_add(&mythos->timer, mythos->frame.header.duration);
    }
    return samples - (unsigned char*)bufA;
}
static int readMPEGChunkA(FILE* f, mpegMythos* mythos, signed char* bufA)
{
    int readed=0;
    unsigned int nsamples = (READ / (SAMPLE_DEPTH / 8)) >>
        (mythos->stereo ? 1 : 0);

    unsigned char *samples = (unsigned char*)bufA;

    while (nsamples)
    {
        unsigned int count, bitrate;

        count = mythos->synth.pcm.length - mythos->samplecount;

        if (count > nsamples)
            count = nsamples;

        if (count)
        {
			mad_fixed_t const *ch1, *ch2;

			ch1 = mythos->synth.pcm.samples[0] + mythos->samplecount;
			ch2 = mythos->synth.pcm.samples[1] + mythos->samplecount;

			if (mythos->stereo == false)
				ch2 = 0;
			else if (mythos->synth.pcm.channels == 1)
				ch2 = ch1;

			pack_pcm(&samples, count, ch1, ch2);

			mythos->samplecount += count;

			nsamples             -= count;

            if (nsamples == 0)
                break;
        }

        while (mad_frame_decode(&mythos->frame, &mythos->stream) == -1)
        {
			// DWORD bytes;
			unsigned int bytes;
			if (MAD_RECOVERABLE(mythos->stream.error))
				continue;
			
			if (mythos->stream.next_frame)
			{
				memmove(mythos->buffer, mythos->stream.next_frame,
					mythos->buflen = mythos->buffer +
					mythos->buflen - mythos->stream.next_frame);
			}

			bytes=fread(mythos->buffer + mythos->buflen,1,sizeof(mythos->buffer) - mythos->buflen,f);

			if(bytes<=0)
			{
				return NULL;
			}

			mad_stream_buffer(&mythos->stream,
                mythos->buffer, mythos->buflen += bytes);
        }

        bitrate = mythos->frame.header.bitrate / 1000;

        mythos->rate += bitrate;
        mythos->frames++;

        //        mythos->info.m_iBitRate_Kbs = bitrate;

        mad_synth_frame(&mythos->synth, &mythos->frame);

        mythos->samplecount = 0;

        mad_timer_add(&mythos->timer, mythos->frame.header.duration);
    }
    return samples - (unsigned char*)bufA;
}
static void cleanup(mpegMythos *context)
{
    mad_synth_finish(&context->synth);
    mad_frame_finish(&context->frame);
    mad_stream_finish(&context->stream);
}
static mpegMythos *openMPEG(FILE* f)
{
	fseek(f, 0, SEEK_SET);
    mpegMythos* mythos=(mpegMythos*)malloc(sizeof(mpegMythos));
    memset(mythos,0,sizeof(mpegMythos));
	//===========================
	// Skip over ID3v2 tag (if there is one)
	//if (context->m_pInStream->IsSeekable(context->m_pInStream) == TRUE) // only works on seekable streams
	{
		CIs_ID3v2Tag tag;
		unsigned int iBytesRead;
		fpos_t iStreamStart=0;
		memset(&tag, 0, sizeof(tag));
		//context->m_pInStream->Read(context->m_pInStream, &tag, sizeof(tag), &iBytesRead);
		iBytesRead = fread(&tag, 1, sizeof(tag), f);
		
		if (memcmp(tag.m_cTAG, "ID3", 3) == 0)
		{
			iStreamStart = sizeof(CIs_ID3v2Tag);
			iStreamStart += (tag.m_cSize_Encoded[0] << 21)
				| (tag.m_cSize_Encoded[1] << 14)
				| (tag.m_cSize_Encoded[2] << 7)
				| tag.m_cSize_Encoded[3];
		}
		
		//context->m_pInStream->Seek(context->m_pInStream, iStreamStart);
		fseek(f, (long)iStreamStart, SEEK_SET);
		//fsetpos(f, &iStreamStart);
	}
	//===========================
	mad_stream_init(&mythos->stream);

	mad_frame_init(&mythos->frame);
	mad_synth_init(&mythos->synth);

	long bpos = ftell(f);
	int sh = scan_header(f,
		&mythos->frame.header, &mythos->xing);
	if (sh == -1)
	{
		//printf("MPEG: failed to read file header");
		cleanup(mythos);
		free(mythos);
		return NULL;
	}
	//-------------------
	mythos->stereo=
		mythos->frame.header.mode == MAD_MODE_SINGLE_CHANNEL ? false : true;
	fseek(f, bpos, SEEK_SET);
	return mythos;
}
static void closeMPEG(mpegMythos* mythos)
{
    cleanup(mythos);
    free(mythos);
}
//================================================================================
//================================================================================
//================================================================================
//======================================== .NET here ====================

void VorbisEnc::IMpegDec::Close()
{
	closeMPEG(this->mythos);
}
void VorbisEnc::IMpegDec::HWinfo(int* channels, int* samplerate, long* bitrate)
{
	*channels = this->mythos->stereo ? 2 : 1;
	*samplerate = this->mythos->frame.header.samplerate;
	*bitrate = this->mythos->xing.frames==0 ?  this->mythos->frame.header.bitrate : -1;
}
int VorbisEnc::IMpegDec::Initialise(char *stringFile)
{
	//open file
	//this->_mpegfile = fopen(stringFile, "r+b");
	this->_mpegfile = _wfopen((wchar_t*)stringFile, L"rb");
	if(!this->_mpegfile)return 0;

	fseek(this->_mpegfile, 0, SEEK_END);
	this->_mpegfilelength = ftell(this->_mpegfile);
	fseek(this->_mpegfile, 0, SEEK_SET);
	//open mpeg file inner
	this->mythos = openMPEG(this->_mpegfile);
	if(this->mythos==NULL)return 0;

	return 1;
}
int VorbisEnc::IMpegDec::ReadChunk(signed char* data, long sz)
{
	return readMPEGChunkA(this->_mpegfile, this->mythos, data);
}
int VorbisEnc::IMpegDec::ReadChunk32(signed char* data, long sz)
{
	return readMPEGChunkF32(this->_mpegfile, this->mythos, data);
}