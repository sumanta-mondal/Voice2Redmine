#pragma once
using namespace System;

namespace VorbisEnc {

public ref class Tag
{
public:
	~Tag()
	{
		if(track)free(track);
		if(artist)free(artist);
		if(album)free(album);
		if(tracknum)free(tracknum);
		if(year)free(year);
		if(encoder)free(encoder);
		if(genre)free(genre);
		if(publisher)free(publisher);
	}
	Tag()
	{

	}
	void Set(char* tagname, char* data, int len)
	{
		if (memcmp(tagname, "TIT2", 4) == 0)
		{
				if(track)free(track);
				tracklen = len;
				track = (char*)malloc(len);
				memcpy(track, data, len);
		}else
		if (memcmp(tagname, "TPE1", 4) == 0)
		{	
				if(artist)free(artist);
				artistlen = len;
				artist = (char*)malloc(len);
				memcpy(artist, data, len);
		}else
		if (memcmp(tagname, "TALB", 4) == 0)
		{
				if(album)free(album);
				albumlen = len;
				album = (char*)malloc(len);
				memcpy(album, data, len);
			
		}else
		if (memcmp(tagname, "TRCK", 4) == 0)
		{
				if(tracknum)free(tracknum);
				tracknumlen = len;
				tracknum = (char*)malloc(len);
				memcpy(tracknum, data, len);
			
		}else
		if (memcmp(tagname, "TYER", 4) == 0)
		{
			if(year)free(year);
				yearlen = len;
				year = (char*)malloc(len);
				memcpy(year, data, len);
			
		}else
		if (memcmp(tagname, "TENC", 4) == 0)
		{
			if(encoder)free(encoder);
				encoderlen = len;
				encoder = (char*)malloc(len);
				memcpy(encoder, data, len);
			
		}else
		if (memcmp(tagname, "TCON", 4) == 0)
		{
				if(genre)free(genre);
				genrelen = len;
				genre = (char*)malloc(len);
				memcpy(genre, data, len);
		}else
		if (memcmp(tagname, "TPUB", 4) == 0)
		{
				if(publisher)free(publisher);
				publisherlen = len;
				publisher = (char*)malloc(len);
				memcpy(publisher, data, len);
		}
		else
		if (memcmp(tagname, "APIC", 4) == 0)
		{
				if(pic)free(pic);
				piclen = len;
				pic = (char*)malloc(len);
				memcpy(pic, data, len);
		}else
		if (memcmp(tagname, "COMM", 4) == 0)
		{
				if(comment)free(comment);
				commentlen = len;
				comment = (char*)malloc(len);
				memcpy(comment, data, len);
		}else
		{
			printf("unresolved tag '%s' '%s'\r\n", tagname, data);
		}
	}
	char* tracknum;int tracknumlen;
	char* track;int tracklen;
	char* artist;int artistlen;
	char* album;int albumlen;
	char* year;int yearlen;
	char* encoder;int encoderlen;
	char* genre;int genrelen;
	char* publisher;int publisherlen;
	char* pic;int piclen;
	char* comment;int commentlen;
};

public ref class Tags
{
public:
	Tags(void);
	void TryReadTagMp3(FILE* mp3, Tag^ t);
	Tag^ Test(char* mp3file)
	{
		Tag^ t;

		FILE* f = _wfopen((wchar_t*)mp3file, L"rb");

		if(!f)
			return t;
		
		t = gcnew Tag();
		this->TryReadTagMp3(f, t);
		fclose(f);

		return t;
	}
};

}